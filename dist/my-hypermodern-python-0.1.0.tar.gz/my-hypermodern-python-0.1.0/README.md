# my-hypermodern-python

This is the repo resulting from following the hypermodern python article series
