# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['my_hypermodern_python']

package_data = \
{'': ['*']}

install_requires = \
['click>=8.0,<9.0', 'requests>=2.22.0,<3.0.0']

entry_points = \
{'console_scripts': ['hypermodern-python = my_hypermodern_python.console:main']}

setup_kwargs = {
    'name': 'my-hypermodern-python',
    'version': '0.1.0',
    'description': 'my hypermodern Python project',
    'long_description': '# my-hypermodern-python\n\nThis is the repo resulting from following the hypermodern python article series\n',
    'author': 'Alexander Grant',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/Delacoal/my-hypermodern-python',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
